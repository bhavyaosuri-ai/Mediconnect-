# MediConnect
A Spring Boot + HTML/CSS/JavaScript healthcare appointment website.

## Run backend
Requirements: Java 17+ and Maven.
```bash
cd backend
mvn spring-boot:run
```
Backend API: http://localhost:8080/api/hospitals

## Run frontend
Open `frontend/index.html` for the static demo, or serve the `frontend` folder with any static web server.

## Deployment
For a public URL, deploy the frontend to a static host and the Spring Boot backend to a Java host such as Railway. The frontend API base URL in `frontend/js/api.js` should then be changed from localhost to the deployed backend URL.

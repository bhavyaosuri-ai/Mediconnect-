package com.mediconnect.controller;
import com.mediconnect.entity.Doctor; import com.mediconnect.repository.DoctorRepository; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/doctors") @CrossOrigin
public class DoctorController {
 private final DoctorRepository repo; public DoctorController(DoctorRepository repo){this.repo=repo;}
 @GetMapping public List<Doctor> all(){return repo.findAll();}
 @PostMapping public Doctor add(@RequestBody Doctor d){return repo.save(d);}
}
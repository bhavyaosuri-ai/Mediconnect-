package com.mediconnect.entity;
import jakarta.persistence.*;
@Entity public class Doctor {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String name, specialty, hospital, city, phone, experience, availability;
 public Doctor() {}
 public Doctor(String name,String specialty,String hospital,String city,String phone,String experience,String availability){this.name=name;this.specialty=specialty;this.hospital=hospital;this.city=city;this.phone=phone;this.experience=experience;this.availability=availability;}
}
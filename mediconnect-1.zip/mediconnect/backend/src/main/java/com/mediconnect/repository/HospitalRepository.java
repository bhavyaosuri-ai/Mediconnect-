package com.mediconnect.repository;
import com.mediconnect.entity.Hospital; import org.springframework.data.jpa.repository.JpaRepository;
public interface HospitalRepository extends JpaRepository<Hospital,Long> {}
package com.mediconnect;
import com.mediconnect.entity.*; import com.mediconnect.repository.*; import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.Bean; import org.springframework.context.annotation.Configuration;
@Configuration public class DataSeeder {
 @Bean CommandLineRunner seed(HospitalRepository hr, DoctorRepository dr){
  return args -> {
   if(hr.count()==0){hr.save(new Hospital("Manipal Hospital","Vijayawada","Tadepalli","0866-000000","24/7","4.8"));hr.save(new Hospital("Andhra Hospitals","Vijayawada","Governorpet","0866-111111","24/7","4.7"));hr.save(new Hospital("NRI General Hospital","Vijayawada","Mangalagiri","0866-222222","24/7","4.6"));}
   if(dr.count()==0){dr.save(new Doctor("Dr. Ananya Rao","General Medicine","Manipal Hospital","Vijayawada","9000000001","8 years","Mon-Sat"));dr.save(new Doctor("Dr. Kiran Kumar","Cardiology","Andhra Hospitals","Vijayawada","9000000002","12 years","Mon-Fri"));dr.save(new Doctor("Dr. Priya Sharma","Pediatrics","NRI General Hospital","Vijayawada","9000000003","10 years","Tue-Sun"));}
  };
 }
}
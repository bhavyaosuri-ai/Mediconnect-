package com.mediconnect.controller;
import com.mediconnect.entity.Appointment; import com.mediconnect.repository.AppointmentRepository; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/appointments") @CrossOrigin
public class AppointmentController {
 private final AppointmentRepository repo; public AppointmentController(AppointmentRepository repo){this.repo=repo;}
 @GetMapping public List<Appointment> all(){return repo.findAll();}
 @PostMapping public Appointment add(@RequestBody Appointment a){a.status="CONFIRMED"; return repo.save(a);}
}
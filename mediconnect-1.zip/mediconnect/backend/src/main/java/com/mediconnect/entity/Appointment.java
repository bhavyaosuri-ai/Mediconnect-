package com.mediconnect.entity;
import jakarta.persistence.*;
@Entity public class Appointment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String patientName, phone, doctorName, hospitalName, date, time, reason, status;
 public Appointment() {}
}
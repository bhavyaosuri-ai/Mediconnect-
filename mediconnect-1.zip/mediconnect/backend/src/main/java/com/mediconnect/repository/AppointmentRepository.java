package com.mediconnect.repository;
import com.mediconnect.entity.Appointment; import org.springframework.data.jpa.repository.JpaRepository;
public interface AppointmentRepository extends JpaRepository<Appointment,Long> {}
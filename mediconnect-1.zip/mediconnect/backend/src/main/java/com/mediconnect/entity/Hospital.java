package com.mediconnect.entity;
import jakarta.persistence.*;
@Entity public class Hospital {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String name, city, address, phone, emergency, rating;
 public Hospital() {}
 public Hospital(String name,String city,String address,String phone,String emergency,String rating){this.name=name;this.city=city;this.address=address;this.phone=phone;this.emergency=emergency;this.rating=rating;}
}
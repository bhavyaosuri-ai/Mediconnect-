package com.mediconnect.controller;
import com.mediconnect.entity.Hospital; import com.mediconnect.repository.HospitalRepository; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/hospitals") @CrossOrigin
public class HospitalController {
 private final HospitalRepository repo; public HospitalController(HospitalRepository repo){this.repo=repo;}
 @GetMapping public List<Hospital> all(){return repo.findAll();}
 @PostMapping public Hospital add(@RequestBody Hospital h){return repo.save(h);}
}
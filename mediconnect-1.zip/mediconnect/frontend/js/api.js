const API='http://localhost:8080/api';
async function getJSON(path){const r=await fetch(API+path);if(!r.ok)throw new Error('API error');return r.json()}
async function postJSON(path,data){const r=await fetch(API+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});if(!r.ok)throw new Error('API error');return r.json()}